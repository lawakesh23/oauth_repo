const path = require('path');
const fs = require('fs');
const webpack = require('webpack');
const packageConfig = require('./package.json');
const gitInfo = (require('gitinfo').default)();
const JSONMinifyPlugin = require('node-json-minify');
const CopyPlugin = require('copy-webpack-plugin');
const ESLintPlugin = require('eslint-webpack-plugin');

const generateArtifact = process.env.generateArtifact || false;

const versionName = Number(Math.floor((new Date()).getTime() / 1000)).toString(24).toUpperCase();
console.info('<------------------------------------Starting------------------------------------->');

console.info('<------------------------------------Removing old build files------------------------------------->');
removetarget(path.resolve(__dirname, 'target/'));
console.info('<------------------------------------Removed old build files------------------------------------>');

console.info('<------------------------------------Checking if new target folder exists!------------------------------------>');
if (!fs.existsSync(path.resolve(__dirname, 'target/' + versionName))) {
  console.info('<------------------------------------Creating new target folder...------------------------------------->');
  fs.mkdirSync(path.resolve(__dirname, 'target/' + versionName));
}

console.info('<------------------------------------Writing build info to ...buildVersionInfo.js & version.txt & buildInfo.json----------->');
fs.writeFileSync(path.resolve(__dirname, 'target/' + versionName + '/buildVersionInfo.js'),
'export default ' +
JSON.stringify(buildVersionInfo(), undefined, 3) +
';');

fs.writeFileSync(path.resolve(__dirname, 'version.txt'),
getVersionTag()
);

fs.writeFileSync(path.resolve(__dirname, 'target/version.txt'),
versionName
);

fs.writeFileSync(path.resolve(__dirname, 'target/targetVersion.js'),
'export default ' +
JSON.stringify(targetVersionInfo(), undefined, 3) +
';');

fs.writeFileSync(path.resolve(__dirname, 'target/buildInfo.json'),
JSON.stringify(getMultiVersionBuildInfo(), undefined, 3)
);

console.info('<------------------------------------Starting Webpack tasks now!!------------------------------------->');

module.exports.config = {

  entry: "./src/main.js",

  target: ["web", "es5"],

  resolve: {

    extensions: ['.js', '.jsx', '.tsx', '.ts', '.css'],
    
    modules: [
      path.resolve(__dirname, 'node_modules'),
      path.resolve(__dirname, 'target/')
    ],

  },

  module: {

    rules: [

      {
        test:  /\.(js|jsx)$/,
        use: ['babel-loader'],
        exclude: [
          path.resolve(__dirname, 'node_modules')
        ]
      },

      { 
        test: /\.tsx?$/, 
        loader: "ts-loader",
        options: {
          transpileOnly: true,
        },
        exclude: /node_modules/
      },
      {
        test: /\.(jp(e*)g|png|gif)/, loader: 'file-loader', options: {
            name: 'asset/resource'
        }
      },
      {
        test: /\.svg$/,
        use: ['@svgr/webpack'],
      },
      {
          test: /\.(eot|ttf|woff|woff2)/,
          type: 'asset/resource'
      }

    ]

  },

  plugins: [

    new webpack.DefinePlugin({
      'WP_ICONS_PATH': '',
      '__REACT_DEVTOOLS_GLOBAL_HOOK__': '({ isDisabled: true })'
    }),

    new ESLintPlugin({
      files: ["./src/**/*.js"]
    }),
    // new CopyPlugin({
    //   patterns: [
    //     // { from: path.resolve(__dirname, './static/fonts/'), to: path.resolve(__dirname, 'target/' + versionName + '/fonts/') },
    //     // {
    //     //   from: path.resolve(__dirname, 'locale_js/catalogs/'),
    //     //   transform: function (content) {
    //     //     return JSONMinifyPlugin(content.toString());
    //     //   },
    //     //   to: path.resolve(__dirname, './target/' + versionName + '/misc/localize/')
    //     // }
    //   ]
    // })
  ]

}


function getVersionTag() {
  return [packageConfig.name, gitInfo.getBranchName(), process.env.BUILD_NUMBER || 'dev', gitInfo.getHeadSha().slice(-7)].join('-');
}

function buildVersionInfo() {
  return {
    version: getVersionTag()
  };
}

function targetVersionInfo() {
  return {
    version: versionName
  };
}

function getMultiVersionBuildInfo() {
  let branchName = gitInfo.getBranchName();
  if (branchName) {
    let releaseVersion = branchName.replace("r_","");
    return {
      version: releaseVersion,
      branchName: branchName
    };
  } else {
    // grunt.warn("whoops, not good.  release version hasn't been set  yet.");
  }
}

function removetarget(dirPath) {
  if (!fs.existsSync(dirPath)) {
    console.info('<------------------------------------Target folder did not exist. Creating one now...------------------------------------->');
    fs.mkdirSync(dirPath);
    return;
  }
  try { var files = fs.readdirSync(dirPath); }
  catch (e) { console.error(e); return; }
  if (files.length > 0)
  for (var i = 0; i < files.length; i++) {
    var filePath = dirPath + '/' + files[i];
    if (fs.statSync(filePath).isFile())
    fs.unlinkSync(filePath);
    else
    rmDir(filePath);
  }
}

function rmDir(dirPath) {
  try { var files = fs.readdirSync(dirPath); }
  catch (e) { console.error(e); return; }
  if (files.length > 0)
  for (var i = 0; i < files.length; i++) {
    var filePath = dirPath + '/' + files[i];
    if (fs.statSync(filePath).isFile())
    fs.unlinkSync(filePath);
    else
    rmDir(filePath);
  }
  fs.rmdirSync(dirPath);
}
module.exports.versionName = versionName;
module.exports.getVersionTag = getVersionTag;