var express = require('express');
var fs = require('fs')
var app = express();

fs.readFile('./target/version.txt', 'utf-8', function(err, data){
    console.log(data)
    var folderLocation = './target/'+ data;
    app.use('/local', express.static(folderLocation));
    app.use(function(req, res){
        res.setHeader('Access-Control-Allow-Origin', "*");
    })
    var server = app.listen(3000, function(){
        var host = server.address().address;
        var port = server.address().port;

        console.log('Example app is listening at http://%s:%s', host, port)
    })
})
