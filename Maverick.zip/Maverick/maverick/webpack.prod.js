const path = require("path");
const { merge } = require("webpack-merge");
const common = require("./webpack.common");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
//const CopyPlugin = require('copy-webpack-plugin');
const webpack = require("webpack");
const exec = require("child_process").exec;
const CompressionPlugin = require("compression-webpack-plugin");
const zlib = require("zlib");

module.exports = merge(common.config, {
  mode: "production",
  output: {
    path: path.resolve(__dirname, "target", common.versionName),
    filename: `./maverick.js`,
  },
  module: {
    //for unbundled files
    rules: [
      {
        test: /\.(css|less)$/,
        use: [
          {
            loader: MiniCssExtractPlugin.loader,
          },
          {
            loader: "css-loader",
            options: { url: false },
          },
          {
            loader: "less-loader",
            options: {
              lessOptions: {
                relativeUrls: false,
              },
            },
          },
        ],
      },
    ],
  },
  plugins: [
    //for bundled files
    new webpack.DefinePlugin({
      STATIC_ASSETS_MAVERICK_PATH:
        "'/maverick/target/" + `${common.versionName}` + "/'",
    }),
    new MiniCssExtractPlugin({
      filename: "./maverick.css",
    }),
    new CompressionPlugin({
      test: /\.js(\?.*)?$/i,
      filename: "[path][base].br",
      algorithm: "brotliCompress",
      compressionOptions: {
        params: {
          [zlib.constants.BROTLI_PARAM_QUALITY]: 11,
        },
      },
      deleteOriginalAssets: false,
    }),
    {
      apply: (compiler) => {
        compiler.hooks.afterEmit.tap("AfterEmitPlugin", (compilation) => {
          exec(
            "cd target/ && tar czf " +
              `${common.getVersionTag()}` +
              ".tar.gz * && cd ..",
            (err, stdout, stderr) => {
              if (stdout) process.stdout.write(stdout);
              if (stderr) process.stderr.write(stderr);
            }
          );
        });
      },
    },
  ],
});
