import sum from '../core/sum'
import * as React from "react";
import "jest";
import {describe, expect, test, jest, it, beforeEach, afterEach} from '@jest/globals';

test('adds 1 + 2 to equal 3', () => {
  expect(sum(1, 2)).toBe(3);
});