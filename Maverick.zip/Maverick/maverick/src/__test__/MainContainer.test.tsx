import "jest";
import {describe, expect, test, jest, it, afterAll, beforeAll} from '@jest/globals';
import React, { useRef } from 'react';
import MainContainer from '../core/MainContainer';
import {render, getByText, fireEvent} from '@testing-library/react'
import { useTranslation } from 'react-i18next';

