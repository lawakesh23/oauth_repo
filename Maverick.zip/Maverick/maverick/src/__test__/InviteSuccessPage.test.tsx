import "jest";
import {describe, expect, test, jest, it, afterAll, beforeAll} from '@jest/globals';
import React, { useRef } from 'react';
import InviteSuccessPage from '../core/InviteSuccessPage';
import {render, getByText, fireEvent} from '@testing-library/react'
import { useTranslation } from 'react-i18next';

// Mock the CheckMarckCircled component
jest.mock('../../static/images/checkmark_circled.svg', () => () => (
    <svg data-testid="checkmark-circled" />
  ));
 
const original = window.location;
const reloadFn = () => {
      window.location.reload();
};
  
  beforeAll(() => { 
      Object.defineProperty(window, 'location', {
        configurable: true,
        value: { reload: jest.fn() },
      });
    });
  
  afterAll(() => {
      Object.defineProperty(window, 'location', { configurable: true, value: original });
  });  

describe('InviteSuccessPage page', () => {
  
    it('renders InviteSuccessPage component correctly', () => {
        const { getByText, getByTestId } = render(<InviteSuccessPage />);

    });

    test('calls the requestInviteLink function on link click', () => {
        const mockReload = jest.fn();
        window.location.reload = mockReload;
    
        const {getByText}=render(<InviteSuccessPage />);
        const link = getByText('invite_expired.success.article.part2');
        fireEvent.click(link);
        reloadFn();
        expect(window.location.reload).toHaveBeenCalled();
      });
});