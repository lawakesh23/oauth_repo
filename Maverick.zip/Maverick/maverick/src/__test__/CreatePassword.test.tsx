import "jest";
import {describe, expect, test, jest, it, beforeEach, afterEach} from '@jest/globals';
import { render, fireEvent } from '@testing-library/react';
import CreatePassword from '../core/CreatePassword';
import { useTranslation } from 'react-i18next';
import React, { useRef } from 'react';

const props = {
  email: 'test@example.com',
  emailToken: 'testToken',
  pwdPolicy: {
    id: 12345,
    passwordMinChars: 6,
    requireUpperCaseLetters: true,
    upperCaseLettersValue: 1,
    requireLowerCaseLetters: true,
    lowerCaseLettersValue: 1,
    requireNumericCharacters: true,
    numericCharactersValue: 1,
    requireSpecialCharacters: true,
    specialCharactersValue: 1,
    noUserSpecificInformation: false,
    passwordChangeOptions: "ALLOW",
    passwordChangeDays: 30,
    notifyFailedAttempts: false,
    notifyFailedAttemptsValue: 2,
    forceModeratorLoginEnabled: true,
    moderatorIpList: 2,
    passwordHistoryCount: 2,
    isUsed: true,
    name: "Maximum Characters long",
    value: 24,
    
  },
  sendEmail: 'send@bluejeanas.com',
};


  test('renders CreatePassword component', () => {
    //  Render the component and check if it renders without crashing
    render(<CreatePassword {...props} />);
    
  });

  test('disables the "Continue" button until valid passwords are entered', () => {
    const { getByText, getByTestId } = render(<CreatePassword {...props}  />);
    const continueButton = getByText('action.button.continue');
    const passwordInput1 = getByTestId('passwordInput1');
    const passwordInput2 = getByTestId('passwordInput2');
    
    // Enter different passwords in both inputs
    fireEvent.change(passwordInput1, { target: { value: 'Password@123' } });
    fireEvent.change(passwordInput2, { target: { value: 'differentPassword' } });
    
    // Check if the "Continue" button is disabled
    expect(continueButton.getAttribute("disabled")).toBeDefined();
    
     ///Enter matching passwords in both inputs
    fireEvent.change(passwordInput2, { target: { value: 'Password@123' } });
    
    // Check if the "Continue" button is enabled
    expect(continueButton.getAttribute("disabled")).toBeNull();

  }); 


  // test('Click event on continue button', async () => {
  //   const onPasswordSubmit = jest.fn();
  //   const { getByText, findByTestId, getByTestId } = render(<CreatePassword {...props} {...onPasswordSubmit} />);
  //   const continueButton = getByText('action.button.continue');
  //   const passwordInput1 = getByTestId('passwordInput1');
  //   const passwordInput2 = getByTestId('passwordInput2');
    
  //   // Enter different passwords in both inputs
  //   fireEvent.change(passwordInput1, { target: { value: 'password123' } });
  //   fireEvent.change(passwordInput2, { target: { value: 'password123' } });
    
  //   fireEvent.click(continueButton);
  //   const loaderElement = await findByTestId('loader');
  //   expect(loaderElement).not.toBeDefined();
  //   expect(onPasswordSubmit).toHaveBeenCalledTimes(1)
  
  // }); 


  test('test Max length for inputs field', async () => {
    const {getByTestId } = render(<CreatePassword {...props} />);
    const passwordInput1 = getByTestId('passwordInput1');
    const passwordInput2 = getByTestId('passwordInput2');
    expect(passwordInput1.getAttribute("maxlength")).toBe("24");
    expect(passwordInput2.getAttribute("maxlength")).toBe("24");

  });