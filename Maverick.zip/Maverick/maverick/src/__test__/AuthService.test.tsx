import "jest";
import {describe, expect, test, jest, it, beforeEach, afterEach} from '@jest/globals';
import { loginUser, IPwdLoginResponse } from '../controller/AuthService';
import BaseController from "../controller/BaseController";

jest.mock('axios');
  const mockPost = jest.fn();

beforeEach(() => {
    // Clear the mock function's calls and instances before each test
    mockPost.mockClear();
});

afterEach(() => {
    jest.resetAllMocks();
});

test('should return a successful login response', async () => {

  const emailToken = 'email_token';
  const email = 'test@bluejeans.com';
  const password = 'dummy@password23';

  const mockdata = {
    status: 200,
    data: {
      access_token: 'abcdefgh',
      expires_in: 3600,
      scope: {
        user: 123,
        partitionName: 'Partition 1',
        partition: { id: 1, name: 'Partition 1' },
        capabilities: [],
      },
      refresh_token: 'refresh_token_value',
    },
  }

  // Mocking BaseController.post method to return a successful response
  const mockPost = jest.fn().mockResolvedValue(mockdata);
  BaseController.prototype.post = mockPost;

  const result : IPwdLoginResponse = await loginUser(emailToken, email, password);
  expect(result.status).toBe(200);
  expect(result.data.access_token).toBe('abcdefgh');
  expect(result.data.scope.user).toBe(123);
  expect(result).toEqual(mockdata);

});

test('should return a unsuccessful login response', async () => {

    const emailToken = 'uvwxyz';
    const email = 'invalid-email@bluejeans.com';
    const password = 'invalid-password';
  
    const errorResponse = {
      status: 401,
      statusText: 'Unauthorized',
      data: {
        message: 'Invalid credentials'
      }
    };
    // Mocking the BaseController.post method to return a unsuccessful response
    const mockPost = jest.fn().mockRejectedValueOnce(errorResponse);
    BaseController.prototype.post = mockPost;
  
  
    const result : IPwdLoginResponse = await loginUser(emailToken, email, password);
    expect(result).toEqual({
      status: 401,
      data: null,
      error: {
        code: 418,
        message: 'Error: Unauthorized'
      }
    });

    // Expect the Axios post method to be called with the correct arguments
    expect(mockPost).toHaveBeenCalledWith(
      'seamapi/oauth2/token',
      {
        grant_type: 'password',
        username: email,
        password: password
      }
    );
    expect(result.status).toBe(401);
    expect(result.data).toBeNull();
    expect(result.error.code).toBe(418);
    expect(result.error.message).toBe('Error: Unauthorized');
  });