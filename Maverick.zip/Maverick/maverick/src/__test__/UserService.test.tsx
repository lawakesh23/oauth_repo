import "jest";
import {describe, expect, test, jest, it, beforeEach, afterEach} from '@jest/globals';
import { fetchEmailValidationStatus, IValidateResponse,  fetchPasswordPolicy, IPwdPolicyResponse, updatePassword, sendInviteLink } from '../controller/UserService';
import BaseController from "../controller/BaseController";
import { AxiosError, AxiosResponse } from 'axios';

jest.mock('axios');
const mockGet = jest.fn();
const mockPost = jest.fn();
const mockPut = jest.fn();

beforeEach(() => {
    // Clear the mock function's calls and instances before each test
    mockGet.mockClear();
    mockPost.mockClear();
    mockPut.mockClear();
});

afterEach(() => {
    jest.resetAllMocks();
});

describe('UserService', () => {
  
    it('fetchEmailValidationStatus success case', async () => {
        const emailToken = 'sgdrefvvffhgergfcx';
        const email = 'test@bluejeans.com';
        const mockResponse = {
            status: 200
        }
        // Mocking BaseController.get method to return a successful response
        const mockGet = jest.fn().mockResolvedValue(mockResponse);
        BaseController.prototype.get = mockGet;

        const result : IValidateResponse = await fetchEmailValidationStatus(emailToken, email);
        expect(result).toBe(200);
        expect(result).toEqual(mockResponse.status);
    });

    it('fetchEmailValidationStatus failed case', async () => {
        const emailToken = 'kjshfdksfshfksdfksf';
        const email = 'test@bluejeans.com';
        const response = {
            isAxiosError: true,
            message: "Failed to fetch password policy",
          };
          // Mocking BaseController.get method to return a successful response
        const mockGet = jest.fn().mockRejectedValue(response);
        BaseController.prototype.get = mockGet;

        const result : AxiosError = await fetchEmailValidationStatus(emailToken, email);
        expect(result).toBe(0);
    });

    it("should return the correct password policy when fetched successfully", async () => {
        
        const emailToken = "dsfhskfhsffsdkfjds";
        const email = "test@bluejeans.com";
        const response = {
          id: 12345,
          passwordMinChars: 8,
          requireUpperCaseLetters: true,
          upperCaseLettersValue: 1,
          requireLowerCaseLetters: true,
          lowerCaseLettersValue: 1,
          requireNumericCharacters: true,
          numericCharactersValue: 1,
          requireSpecialCharacters: true,
          specialCharactersValue: 1,
          noUserSpecificInformation: true,
          passwordChangeOptions: "ALLOW",
          passwordChangeDays: 90,
          notifyFailedAttempts: true,
          notifyFailedAttemptsValue: 3,
          forceModeratorLoginEnabled: true,
          passwordHistoryCount: 5,
        };
        // Mock the BaseController's 'get' method to return a successful response
        const mockGet = jest.fn().mockResolvedValue(response);
        BaseController.prototype.get = mockGet;
    
        const passwordPolicy : (IPwdPolicyResponse & AxiosError) = await fetchPasswordPolicy(email, emailToken);
        expect(passwordPolicy).toEqual(response);
        expect(mockGet).toHaveBeenCalledWith(`seamapi/v1/user/password-reset/policy?email=${encodeURIComponent(email)}`);
    });

    it("should return the failed password policy", async () => {
        // Mock the BaseController's 'get' method to return a failed response
        const emailToken = "dsfhskfhsffsdkfjds";
        const email = "test@bluejeans.com";
        const response = {
            isAxiosError: true,
            message: "Failed to fetch password policy",
          };
        const mockGet = jest.fn().mockRejectedValueOnce(response);
        BaseController.prototype.get = mockGet;
    
        const passwordPolicy : (IPwdPolicyResponse & AxiosError) = await fetchPasswordPolicy(email, emailToken);
       // expect(passwordPolicy).toEqual(response);
        expect(mockGet).toHaveBeenCalledWith(`seamapi/v1/user/password-reset/policy?email=${encodeURIComponent(email)}`);
    });

    it("should return true for success when status is 200 for the sendInviteLink", async () => {  

        const email = 'test@bluejeans.com';
        const mockResponse = {
          status: 200,
        };
        // Mocking the BaseController.post method to return a successful response
        const mockPost = jest.fn().mockResolvedValue(mockResponse);
        BaseController.prototype.post = mockPost;

        const result = await sendInviteLink(email);
        expect(result).toBe(true);
    });
    it("Failed case when status is not in 200-299 for the sendInviteLink", async () => {  

        const email = 'test@bluejeans.com';
        const mockResponse = {
          status: 300,
        };
        const mockPost = jest.fn().mockResolvedValue(mockResponse);
        BaseController.prototype.post = mockPost;

        const result = await sendInviteLink(email);
        expect(result).toBe(false);
    });

    it("should return status 200 for success for the updatePassword", async () => {  

        const emailToken = 'test_token';
        const email = 'test@bluejeans.com';
        const password = 'dummy@password23';
        const sendEmail = 'true';
      
        const mockdata = {
            status: 200,
            data: { message: 'Password updated successfully' },
        }
        const mockPut = jest.fn().mockResolvedValue(mockdata);
        BaseController.prototype.put = mockPut;

        const result = await updatePassword(emailToken, email, password, sendEmail);
        expect(result.status).toBe(200);
        expect(result.data.message).toEqual("Password updated successfully");
        expect(result).toEqual(mockdata);

    });

    it('should handle an error response and return the appropriate error object', async () => {

        const mockErrorResponse = {
            response: {
              status: 400,
              data: { code: 123, details: { constraintViolations: [{ message: 'Invalid email' }] } },
            },
          };
        const mockPut = jest.fn().mockRejectedValueOnce(mockErrorResponse);
        BaseController.prototype.put = mockPut;
    
        const email = 'test@example.com';
        const emailToken = 'test_token';
        const password = 'new_password';
        const sendEmail = 'true';
    
        const result = await updatePassword(email, emailToken, password, sendEmail);
    
        // Check if the BaseController.put method is called with the correct arguments
        expect(mockPut).toHaveBeenCalledWith(
          `seamapi/v1/user/password-reset?email=${encodeURIComponent(email)}&sendEmail=${sendEmail}`,
          { password: password }
        );
    
        // the expected error object values
        expect(result.error.code).toEqual(418);
        expect(result.status.response.status).toEqual(400);

    });
      
});
