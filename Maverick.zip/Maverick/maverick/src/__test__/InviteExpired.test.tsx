import "jest";
import {describe, expect, test, jest, it, afterAll, beforeAll} from '@jest/globals';
import React, { useRef } from 'react';
import InviteExpired from '../core/InviteExpired';
import {render, getByText, fireEvent} from '@testing-library/react'
import { useTranslation } from 'react-i18next';

// Mock the useTranslation hook
jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: key => key }), // Mock the translation function
}));

const original = window.location;
const reloadFn = () => {
    window.location.reload();
};

beforeAll(() => { 
    Object.defineProperty(window, 'location', {
      configurable: true,
      value: { reload: jest.fn() },
    });
  });

afterAll(() => {
    Object.defineProperty(window, 'location', { configurable: true, value: original });
});

const props ={
    email: "dummyemail@bluejeans.com"
}
describe('InviteExpired page', () => {
  
    it('renders Loader component correctly', () => {
        const { getByText, getByTestId } = render(<InviteExpired {...props}  />);

    });

    test('displays correct translations for expire title and article text', () => {
        // Mock the translation function to return custom translated texts
        const mockTranslation = jest.fn(key => {
          if (key === 'invite_expired.title') return 'Custom Header Text';
          if (key === 'invite_expired.success.article.part1') return 'Custom Article Text Part 1';
          if (key === 'invite_expired.success.article.part2') return 'Custom Article Text Part 2';
          return key;
        });
        const {getByText} = render(<InviteExpired {...props} />);
        const expireTitle = getByText('invite_expired.title');
        const articleTextPart1 = getByText('invite_expired.sub_heading.first');
        const articleTextPart2 = getByText('invite_expired.sub_heading.second');
        expect(expireTitle).toBeDefined();
        expect(articleTextPart1).toBeDefined();
        expect(articleTextPart2).toBeDefined();

      });

      it('mocks reload function', () => {
        expect(jest.isMockFunction(window.location.reload)).toBe(true);
      });

      test('calls the requestInviteLink function on link click', () => {
        const {getByText}=render(<InviteExpired {...props} />);
        const link = getByText('action.button.req_another_link');
        fireEvent.click(link);

      });
});