import "jest";
import {describe, expect, test, jest, it} from '@jest/globals';
import React, { useRef } from 'react';
import Loader from '../common/Loader';
import {render} from '@testing-library/react'

describe('Loading page', () => {
  
    it('renders Loader component correctly', () => {
      const { getByTestId } = render(
        <Loader />
      );
      const loader = getByTestId('loader');
      expect(loader).toBeDefined();
      expect(loader.getAttribute('alt')).toBe("Loading..");
      expect(loader.getAttribute('height')).toBe("49px");

    });
});
  