/** @jsx jsx */
import { jsx, css } from '@emotion/react';
import React from 'react';
import { useTranslation } from 'react-i18next';

import CheckMarckCircled from "../../static/images/checkmark_circled.svg";

/* #region  CSS */
const flex = css({
  display: 'flex',
  flexDirection: 'column'
});

const center = css({
  justifyContent: 'flex-start',
  alignItems: 'center'
});

const sectionCss = css`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const headerCss = css`
  font-family: 'ProximaNovaSemiBold';
  font-size: 36px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #4a4a4a;
  `;

const articleText = css`
  width: 95%;
  max-width: 625px;
  font-size: 18px;
  font-weight: normal;
  font-stretch: normal;
  line-height: 1.44;
  letter-spacing: normal;
  text-align: center;
  color: #4a4a4a;
`;

const articleTextLink = css`
  font-family: 'ProximaNovaSemibold';
  font-weight: 600;
  color: #0d62c5;
  text-decoration: underline;
  cursor: pointer;
`;
/* #endregion */

const InviteSuccessPage = () : JSX.Element => {

  const { t } = useTranslation();

  const navigateBack = () => window.location.reload();

  return (
    <div css={[flex, center, {marginTop: "1rem"}]}>
      <section css={sectionCss}>
        <header css={[sectionCss, {marginBottom: "1.4rem"}]}>
          <div css={{marginBottom: "2.14rem"}}><CheckMarckCircled/></div>
          <div css={headerCss}>{t('invite_expired.success.header')}</div>
        </header>
        <article>
          <p css={articleText}>{t('invite_expired.success.article.part1')} <a css={articleTextLink} onClick={navigateBack}>{t('invite_expired.success.article.part2')}</a></p>
        </article>
      </section>
    </div>
  );
};

export default InviteSuccessPage;
