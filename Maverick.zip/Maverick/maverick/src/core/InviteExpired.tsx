/** @jsx jsx */
import { jsx, css } from '@emotion/react';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import Button from '../common/Button';
import Analytics from "../util/analytics";
import { mediaQuery } from '../util/mediaQuery';
import { sendInviteLink } from '../controller/UserService';
import ExpirationIcon from "../../static/images/linkExpiration_Icon.svg";
import Loader from '../common/Loader';
import InviteSuccessPage from './InviteSuccessPage';
import { capitalizeText } from '../util/common';
import { error } from '../common/Notification';

/* #region CSS */
const flex = css({
  display: 'flex',
  flexDirection: 'column'
});

const center = css({
  justifyContent: 'flex-start',
  alignItems: 'center'
});

const bold = css({
  fontFamily: "ProximaNovaBold"
});

const textCommon = css({
  fontStretch: "normal",
  fontStyle: "normal",
  lineHeight: "normal",
  letterSpacing: "normal",
  color: "#4a4a4a"
});

const header = css({
  fontSize: "36px",
});

const subHeader = css({
  alignItems: 'center',
  lineHeight: "26px",
  fontSize: "18px",
});


const styledButton = css({
  height: "2.714rem",
  borderRadius: "1.85rem",
  marginTop: '18px',
  [mediaQuery('small')]: {
    width: "60rem",
    fontSize: "18px"
  },
  [mediaQuery('large')]: {
    width: "15.43rem",
    fontSize: "14px"
  }
});
/* #endregion */

interface Props {
  email: string,
}

const InviteExpired = ({email} : Props) : JSX.Element => {

  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [successPage, setSuccessPage] = useState(false);

  useEffect(() => {
    const mixpanelObj = {
      Status: "Expired",
      userEmail: email
    };
    email && Analytics.trackEvent('Vz_userLandingCreatePasswordPage', mixpanelObj);
  }, [email]);

  const requestInviteLink = async () => {
    try {
      setLoading(true);
      const sendLinkResponse = await sendInviteLink(email);
      if(!sendLinkResponse) {
        throw new Error("Something went wrong, please try again later ");
      }
      setSuccessPage(true);
      const mixPanelObj = {
        userEmail: email,
        ApiStatus: "Success"
      };
      Analytics.trackEvent('Vz_userRequestNewLink', mixPanelObj);
      setLoading(false);
    } catch (err) {
      const mixPanelObj = {
        userEmail: email,
        ApiStatus: "Failed"
      };
      error(capitalizeText(err.message));
      Analytics.trackEvent('Vz_userRequestNewLink', mixPanelObj);
      setLoading(false);
    }
  };

  return (
    <div css={[flex, center, {rowGap: '2.6rem', marginTop: "9.7rem", marginBottom: "30px",}]}>
      {loading ? <div css={[flex, center, {flex: 1}]} ><Loader/></div> : 
      !successPage ?
      <React.Fragment>
        <section css={[flex, center, {rowGap: '0.7rem'}]}>
          <ExpirationIcon width="106px" height="96px" css={{marginBottom: "1.78rem"}}/>
          <span css={[flex, bold, center, textCommon, header]}>{t('invite_expired.title')}</span>
          <div className="sub-head" css={[flex, textCommon, subHeader]}>
            <span>{t('invite_expired.sub_heading.first')}</span>
            <span>{t('invite_expired.sub_heading.second')}</span>
          </div>
        </section>
        <Button css={styledButton} disabled={!email?.length} onClick={requestInviteLink}>{t('action.button.req_another_link')}</Button>
      </React.Fragment>
      : <InviteSuccessPage/>
      } 
    </div>
  );
};

export default InviteExpired;
