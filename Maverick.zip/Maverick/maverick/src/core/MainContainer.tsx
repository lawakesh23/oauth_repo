/** @jsx jsx */
import { jsx, css } from '@emotion/react';
import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { fetchEmailValidationStatus, fetchPasswordPolicy, IPwdPolicyResponse } from '../controller/UserService';
import Header from '../common/Header';

import CreatePassword from './CreatePassword';
import InviteExpired from './InviteExpired';
import Loader from '../common/Loader';
import React from 'react';

const flex = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
});


const center = css({
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
});


const MainContainer = () : JSX.Element => {

  const [loading, setLoading] = useState(true);
  const [validationStatus, setValidationStatus] = useState(null);

  const search = useLocation().search;
  const params = new URLSearchParams(search);
  const email = params.get("email");
  const emailToken = params.get('hash');
  const sendEmail = params.has('sendEmail') ? params.get('sendEmail') : null;

  useEffect(() => {
    const validateEmail = async () => {
      try {
        const validationStatusResponse = await fetchEmailValidationStatus(email, emailToken);
        if(!validationStatusResponse) throw new Error("Error fetching validation status");
        setValidationStatus(validationStatusResponse);
      } catch (error) {
        setLoading(false);
      }
    };
    validateEmail();
  }, [email, emailToken]);

  const [passwordPolicy, setPasswordPolicy] = useState<IPwdPolicyResponse>();
  useEffect(() => {
    const getPwdPolicy = async () => {
      try {
        const pwdPolicy = await fetchPasswordPolicy(email, emailToken);
        setPasswordPolicy(pwdPolicy);
        setLoading(false);
      } catch (error) {
        setLoading(false);
      }
    };
    if(validationStatus !== null) {
      getPwdPolicy();

    }
  }, [validationStatus, email, emailToken]);

  
  return (
    <div css={[flex, {maxWidth: "100%"}]}>
      {loading ? <div css={[flex, center]} ><Loader/></div> :
      <React.Fragment>
        <Header/>
        <div css={[flex]}>
          { !validationStatus ? <InviteExpired email={email}/> : <CreatePassword email={email} emailToken={emailToken} pwdPolicy={passwordPolicy} sendEmail={sendEmail}/>}
        </div>
      </React.Fragment>
      }
    </div>
  );
};

export default MainContainer;
