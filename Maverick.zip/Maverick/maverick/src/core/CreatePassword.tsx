/** @jsx jsx */
import { jsx, css } from '@emotion/react';
import React, { useRef } from 'react';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import styled from '@emotion/styled';
import Cookie from 'js-cookie';
import Footer from '../common/Footer';
import Button from '../common/Button';
import Input from '../common/Input';
import Popper from '../common/Popper';
import { error } from '../common/Notification';
import Loader from '../common/Loader';

import {mediaQuery} from "../util/mediaQuery";
import { capitalizeText } from '../util/common';
import Analytics from "../util/analytics";
import EyeIcon from "../../static/images/eye_show.svg";
import HiddenEyeIcon from "../../static/images/icon_hide_eye.svg";
import CheckIcon from "../../static/images/icon_checkmark.svg";
import CrossIcon from "../../static/images/icon_x.svg";
import { IPwdPolicyResponse, updatePassword } from '../controller/UserService';
import { IPwdLoginResponse, loginUser } from '../controller/AuthService';

/* #region  CreatePassword CSS */
const flex = css({
  display: 'flex',
  flexDirection: 'column'
});

const grid = css({
  display: 'grid'
});

const center = css({
  justifyContent: 'flex-start',
  alignItems: 'center'
});

const bold = css({
  fontFamily: "ProximaNovaSemiBold"
});

const textCommon = css({
  fontStretch: "normal",
  fontStyle: "normal",
  lineHeight: "normal",
  letterSpacing: "normal",
  color: "#4a4a4a"
});

const header = css({
  fontSize: "36px",
  textAlign: 'center',
  [mediaQuery('small')]: {
    fontSize: "70px",
  },
  [mediaQuery('large')]: {
    fontSize: "36px",
  }
});

const subHeader = css({
  fontFamily: 'ProximaNovaRegular',
  alignItems: 'center',
  lineHeight: "26px",
  fontSize: "18px",
  [mediaQuery('small')]: {
    fontSize: "26px",
  },
  [mediaQuery('large')]: {
    fontSize: "18px",
  }
});

const centerFields = css({
  minWidth: "9rem",
  flex: 1,
  [mediaQuery('small')]: {
    maxWidth: "60rem",
  },
  [mediaQuery('large')]: {
    maxWidth: "23.3rem",
  }
});

const label = css({
  fontSize: "14px",
  color: "#566271",
});

const styledButton = css({
  placeSelf: "center",
  height: "2.714rem",
  borderRadius: "1.85rem",
  width: '100%',
  [mediaQuery('small')]: {
    fontSize: '18px',
    width: "88%"
  },
  [mediaQuery('large')]: {
    fontSize: '14.5px',
    width: "14.4rem",
  }
});

type DropDownProps = {
  visible: boolean
}

const DropdownContainer = styled.div<DropDownProps>`
  display: ${props => (props.visible ? "flex" : "none")};
  flex-direction: column;
  background-color: "#FFF";
  border-radius: 4px;
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.14);
  padding: 5px;
`;

const DropdownItem = styled.div`
  min-height: 24px;
  padding-right: 10px;
  align-items: center;
  font-size: 10px;
  color: #4a4a4a;
  line-height: 1.8;
  display: flex;
  justify-content: flex-start;
  align-items: center;

  &:active {
    font-weight: 700;
    color: #00ffff;
  }
`;
/* #endregion */

interface PwdPolicy {
  passwordMinChars: PolicyCheckItem;
  passwordMaxChars: PolicyCheckItem;
  noUserSpecificInfo?: PolicyCheckItem;
  upperCaseCheck?: PolicyCheckItem;
  lowerCaseCheck?: PolicyCheckItem;
  numericCharCheck?: PolicyCheckItem;
  specialCharCheck?: PolicyCheckItem;
}

interface PolicyCheckItem {
  name: string;
  value: number;
  isUsed?: boolean;
}

const usePasswordPolicyGenerator = (defaultPwdPolicy: IPwdPolicyResponse) => {

  const [passwordPolicy, setPasswordPolicy] = useState<IPwdPolicyResponse>(defaultPwdPolicy);
  const [passPolicy, setPassPolicy] = useState<PwdPolicy>(null);

  useEffect(() => {
    if(passwordPolicy) { // generate formatted policy values
      // eslint-disable-next-line prefer-const
      let pwdPolicy: PwdPolicy = {} as PwdPolicy;

        pwdPolicy["upperCaseCheck"] = {
            name: "Uppercase letter",
            value: passwordPolicy.upperCaseLettersValue || 1,
            isUsed: false
        };
        
        pwdPolicy["lowerCaseCheck"] = {
          name: "LowerCase letter",
          value: passwordPolicy.lowerCaseLettersValue || 1,
          isUsed: false
        };

        pwdPolicy["numericCharCheck"] = {
          name: "Number",
          value: passwordPolicy.numericCharactersValue || 1,
          isUsed: false
        };

        pwdPolicy["specialCharCheck"] = {
          name: "Special character",
          value: passwordPolicy.specialCharactersValue || 1,
          isUsed: false
        };

      if(passwordPolicy.noUserSpecificInformation) {
        pwdPolicy["noUserSpecificInfo"] = {
          name: "No User and Enterprise related text",
          value: null,
        };
      }

      pwdPolicy["passwordMinChars"] = {
        name: "Minimum Characters long",
        value: passwordPolicy?.passwordMinChars || 8,
        isUsed: false
      };

      pwdPolicy["passwordMaxChars"] = {
        name: "Maximum Characters long",
        value: 24,
        isUsed: false
      };

      setPassPolicy(pwdPolicy);
    }
  }, [passwordPolicy]);

  return [passPolicy, setPassPolicy] as const;
};

interface Props {
  email: string,
  emailToken: string,
  pwdPolicy: IPwdPolicyResponse,
  sendEmail: string
}

const CreatePassword = ({email, emailToken, pwdPolicy, sendEmail} : Props) : JSX.Element => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [passwordPolicy, setPasswordPolicy] = usePasswordPolicyGenerator(pwdPolicy);

  const [userPassword1, setUserPassword1] = useState("");
  const [userPassword2, setUserPassword2] = useState("");
  const [buttonStatus, setButtonStatus] = useState(true);


  /* Password Attempts Status */
  const [passwordAttemptStatus, setPasswordAttemptStatus] = useState(false);

  useEffect(() => {
    if(userPassword1.length === 1 && userPassword2.length === 0 && email && !passwordAttemptStatus){
      const mixpanelObj = {
        Status: "Active",
        userEmail: email
      };
      Analytics.trackEvent('Vz_userAttemptedCreatePassword', mixpanelObj);
      setPasswordAttemptStatus(true);
    } else if(userPassword1.length === 0 && userPassword2.length === 1 && email && !passwordAttemptStatus) {
      const mixpanelObj = {
        Status: "Active",
        userEmail: email
      };
      Analytics.trackEvent('Vz_userAttemptedCreatePassword', mixpanelObj);
      setPasswordAttemptStatus(true);
    }  
  }, [email, userPassword1, userPassword2, passwordAttemptStatus]);

  
  useEffect(() => {
    const mixpanelObj = {
      Status: "Active",
      userEmail: email
    };
    email && Analytics.trackEvent('Vz_userLandingCreatePasswordPage', mixpanelObj);
  }, [email]);


  useEffect( () => {
    if(userPassword1 && userPassword2) {
      if(userPassword1 === userPassword2) {
        const hasMetPwdPolicy = !Object.values(passwordPolicy).filter(o => o.isUsed === false).length;
        hasMetPwdPolicy && setButtonStatus(false);
      } else {
        setButtonStatus(true);
      }
    } else {
      setButtonStatus(true);
    }
  }, [userPassword1 ,userPassword2, passwordPolicy]);

  /* #region  Password Icon */
  const [showPassword1, setShowPassword1] = useState(true);
  const [showPassword2, setShowPassword2] = useState(true);

  const onIconClick = (inputName: string) : void => {
    if(inputName === "password1") {
      setShowPassword1(!showPassword1);
    } else {
      setShowPassword2(!showPassword2);
    }
    return;
  };

  const getIcon = (iconEyeState: boolean) : JSX.Element => {
    if(iconEyeState) {
      return <HiddenEyeIcon/>;
    }
    return <EyeIcon/>;
  };
  /* #endregion */

  /* #region Password policy TOOL-TIP */
  const [visible, setVisibility] = useState(false);

  const handleDropdownClick = () => {
    setVisibility(!visible);
  };
  /* #endregion */
  useEffect(() => {
    if (passwordPolicy) {
      if (userPassword1) {
        //check with policy defined rules.
        // eslint-disable-next-line prefer-const
        let updatedPolicy = JSON.parse(JSON.stringify(passwordPolicy));
        if (passwordPolicy?.upperCaseCheck) {
          const isContainsUppercase = /[A-Z]/g;
          updatedPolicy.upperCaseCheck = {
            ...updatedPolicy.upperCaseCheck,
            isUsed: (userPassword1.match(isContainsUppercase) || []).length >= passwordPolicy.upperCaseCheck.value
          };
        }
        if (passwordPolicy?.lowerCaseCheck) {
          const isContainsLowercase = /[a-z]/g;
          updatedPolicy.lowerCaseCheck = {
            ...updatedPolicy.lowerCaseCheck,
            isUsed: (userPassword1.match(isContainsLowercase) || []).length >= passwordPolicy.lowerCaseCheck.value
          };
        }
        if (passwordPolicy?.numericCharCheck) {
          const isContainsNumber = /[0-9]/;
          updatedPolicy.numericCharCheck = {
            ...updatedPolicy.numericCharCheck,
            isUsed: userPassword1.search(isContainsNumber) >= passwordPolicy.numericCharCheck.value
          };
        }
        if(passwordPolicy?.specialCharCheck) {
          const isContainsSymbol = /[!@#$%^&*()_\-=+~?/|\\.]/g;
          updatedPolicy.specialCharCheck = {
            ...updatedPolicy.specialCharCheck,
            isUsed: (userPassword1.match(isContainsSymbol) || []).length >= passwordPolicy.specialCharCheck.value
          };
        }
        if(passwordPolicy?.passwordMinChars) {
          updatedPolicy.passwordMinChars = {
            ...updatedPolicy.passwordMinChars,
            isUsed: userPassword1.length >= passwordPolicy.passwordMinChars.value
          };
        }
        if(passwordPolicy?.passwordMaxChars) {
          updatedPolicy.passwordMaxChars = {
            ...updatedPolicy.passwordMaxChars,
            isUsed: userPassword1.length <= passwordPolicy.passwordMaxChars.value
          };
        }
        setPasswordPolicy(updatedPolicy);
      } else {
        const updatedPolicy = JSON.parse(JSON.stringify(passwordPolicy));
        Object.keys(updatedPolicy).forEach( (k) => {
          if (k !== "noUserSpecificInfo" ) {
            updatedPolicy[k].isUsed = false;
          }});
        setPasswordPolicy(updatedPolicy);
      }
    }
  }, [userPassword1]);

  const onPasswordSubmit = async () => {
    setLoading(true);
    try {
      const pwdUpdateResp = await updatePassword(email, emailToken, userPassword1, sendEmail);
      if (pwdUpdateResp.status !== 200) {
        throw new Error(pwdUpdateResp.error.message);
      }
      const userLoginResp: IPwdLoginResponse = await loginUser(emailToken, email, userPassword1);
      if(userLoginResp.status !== 200) {
        throw new Error("User authorization failed.");
      }
      const refreshToken = userLoginResp.data.refresh_token;
      const expireAt = new Date(new Date().getTime() + userLoginResp.data.expires_in * 1000);
      const cookieName = "bjnat_" + (window as any).ENVIRONMENT_NAME;
      const domain = "." + (window as any).WEB_HOST;
      if(expireAt) {
        Cookie.set(cookieName, userLoginResp.data.access_token, {expires: expireAt, secure: true, domain: domain});
      } else {
        Cookie.set(cookieName, userLoginResp.data.access_token, {secure: true, domain: domain});
      }
      if(refreshToken) {
        const tokenExpiryDays = 365;
        const refreshTokenExpiry = new Date(new Date().getTime() + tokenExpiryDays * 24 * 60 * 60 * 1000);
        const refreshTokenCookieName = "bjnrt_" + (window as any).ENVIRONMENT_NAME;
        Cookie.set(refreshTokenCookieName, refreshToken, {expiresAt: refreshTokenExpiry, secure: true, domain: domain});
      }
      const mixPanelObj = {
        userEmail: email
      };
      Analytics.trackEvent('Vz_userCreatedNewPassword', mixPanelObj);
      window.location.href = `${window.location.protocol}//${window.location.hostname}/scheduling`;
    } catch (err) {
      error(capitalizeText(err.message));
      setLoading(false);
    }
  };

  return (
    <div css={[grid, {marginTop: "12rem", marginBottom: "30px", rowGap: '2.7rem'}]}>
      {loading ? <div css={[flex, center]} ><Loader/></div> :
      <React.Fragment>
        <section css={[grid ,{rowGap: '0.7rem'}]}>
          <span css={[flex, bold, center, textCommon, header]}>{t('create_password.heading')}</span>
          <div className="sub-head" css={[flex, textCommon, subHeader]}>
            <span css={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center'}}>
              {t('create_password.sub_heading.first_part1')}&nbsp;<span css={bold}>{email}</span>&nbsp;{t('create_password.sub_heading.first_part2')}
            </span>
            <span css={{textAlign: 'center'}}>{t('create_password.sub_heading.second')}</span>
          </div>
        </section>
        <div css={{ display: "flex", justifyContent: "center"}}>
          <div css={[flex, centerFields, { display: 'grid', rowGap: '0.2rem'}]}>
            <label css={label} htmlFor="password1">{t('create_password.label.new_pass')}</label>
            {passwordPolicy && <Popper placement={ window.innerWidth <= 1000 ? "bottom" : "left"} >
              <DropdownContainer data-testid="items" visible={visible}>
                {Object.values(passwordPolicy).map( (pwdItem : PolicyCheckItem) => (
                  <DropdownItem key={pwdItem.name}>{Object.prototype.hasOwnProperty.call(pwdItem, 'isUsed') && (pwdItem.isUsed ? <CheckIcon/> : <CrossIcon/>) } {pwdItem !== null && pwdItem.value} {pwdItem.name}</DropdownItem>
                ))}
              </DropdownContainer>
            </Popper>}
            <Input 
              data-testid="passwordInput1"
              autoComplete="off"
              css={{ height: "2.1rem", paddingLeft: 4}}
              name="password1"
              onFocus={handleDropdownClick}
              onBlur={handleDropdownClick}
              type={ !showPassword1 ? "text": "password"}
              maxLength={passwordPolicy?.passwordMaxChars?.value}
              icon={() => getIcon(showPassword1)}
              iconClick={() => onIconClick("password1")}
              value={userPassword1}
              onChange={ (e) => setUserPassword1(e.target.value.trim())}
              max={50}
              />
            
            <label css={[label, {marginTop: '9px'}]} htmlFor="password2">{t('create_password.label.confirm_pass')}</label>
            <Input
              data-testid="passwordInput2"
              autoComplete="off"
              css={{ height: "2.1rem", paddingLeft: 4}}
              name="password2"
              type={ !showPassword2 ? "text": "password"}
              icon={() => getIcon(showPassword2)}
              iconClick={() => onIconClick("password2")}
              value={userPassword2}
              maxLength={passwordPolicy?.passwordMaxChars?.value}
              onChange={ (e) => setUserPassword2(e.target.value.trim())}
              max={50}
            />
          </div>
        </div>
        <Button css={styledButton} disabled={buttonStatus} onClick={onPasswordSubmit}>{t('action.button.continue')}</Button>
      </React.Fragment>
      }
      <Footer/>
    </div>
  );
};

export default CreatePassword;
