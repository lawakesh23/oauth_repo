/** @jsx jsx */
import * as React from 'react';
import { jsx, css } from '@emotion/react';
import * as ReactDOM from 'react-dom';
import {
    BrowserRouter as Router,
    Switch,
    Route,
} from "react-router-dom";
import GlobalStyles from '../common/GlobalStyles';
import MainContainer from './MainContainer';
import "../util/i18n";



ReactDOM.render(
    <Router>
        <GlobalStyles/>
        <div id="react-notifier" css={{position: "fixed", top: "16px"}}></div>
        <Switch>
            <Route path="*/create-password/">
                <MainContainer/>
            </Route>
            <Route path="*">
                <h2>Nothing FOUND</h2>
            </Route>        
        </Switch>
    </Router>,
    document.getElementById('root')
);