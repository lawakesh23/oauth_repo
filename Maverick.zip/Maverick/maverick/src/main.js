// __webpack_public_path__ = window.BJN.appPath;
require("./core/App.tsx");