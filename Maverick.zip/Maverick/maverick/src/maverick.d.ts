declare global {
  interface Window {
      BJN: any;
  }
}
export {};