declare module '*.svg';
declare module '*.gif';
declare module '*.eot';
declare module '*.ttf';
declare module '*.woff';
