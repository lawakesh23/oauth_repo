import BaseController from "./BaseController";
import { AxiosError, AxiosResponse } from 'axios';

interface IValidateResponse {
  status: number
}

interface IPwdPolicyResponse {
  id: number;
  passwordMinChars: number;
  requireUpperCaseLetters: boolean;
  upperCaseLettersValue: number;
  requireLowerCaseLetters: boolean;
  lowerCaseLettersValue: number;
  requireNumericCharacters: boolean;
  numericCharactersValue: number;
  requireSpecialCharacters: boolean;
  specialCharactersValue: number;
  noUserSpecificInformation: boolean;
  passwordChangeOptions: string;
  passwordChangeDays: number;
  notifyFailedAttempts: boolean;
  notifyFailedAttemptsValue: number;
  forceModeratorLoginEnabled: boolean;
  moderatorIpList?: any;
  passwordHistoryCount: number;
}

interface IPwdUpdateResponse {
  status: number,
  data: unknown,
  error?: {
    code?: number,
    message: string
  }
}

const fetchEmailValidationStatus = async (email: string, emailToken: string) : Promise<number> => {
  const path = `seamapi/v1/user/password-reset/validate?email=${encodeURIComponent(email)}`;
  try {
    const validationStatus: (IValidateResponse & AxiosError) = await (new BaseController({accessToken: emailToken}).get(path));
    if(validationStatus.isAxiosError) {
      throw new Error(validationStatus.message);
    }
    return validationStatus.status;
  } catch (error) {
    console.log(error);
    return 0;
  }
};

const fetchPasswordPolicy = async (email: string, emailToken: string): Promise<IPwdPolicyResponse> => {

  const path = `seamapi/v1/user/password-reset/policy?email=${encodeURIComponent(email)}`;

  try {
    const passwordPolicy: (IPwdPolicyResponse & AxiosError) = await (new BaseController({accessToken: emailToken})).get(path);
    if(passwordPolicy.isAxiosError) {
      throw new Error(passwordPolicy.message);
    }
    return passwordPolicy;
  } catch (error) {
    console.log(error);
    return;
  }

};

const sendInviteLink = async (email: string): Promise<boolean> => {
  try {
    const path = `seamapi/v1/user/password-reset/send-link`;
    const reqBody = {
      "email": `${email}`,
      "src": "RIVET"
    };
    const pwdResetResponse = await (new BaseController().post(path, reqBody));
    if(pwdResetResponse.status >=200 && pwdResetResponse.status <=299) {
      return true;
    } else throw new Error("Error sending invitation link");
  } catch (error) {
    console.log(error);
    return false;
  }
};

const updatePassword = async (email: string, emailToken: string, password: string, sendEmail: string): Promise<IPwdUpdateResponse> => {
  try {
    const path = `seamapi/v1/user/password-reset?email=${encodeURIComponent(email)}`+ (
      sendEmail !== null ?
      `&sendEmail=${sendEmail}` 
      : ''
  );
    const reqBody = {
      "password": `${password}`
    };
    const pwdResetResponse: AxiosResponse = await (new BaseController({accessToken: emailToken}).put(path, reqBody));
    if (pwdResetResponse.status >=200 && pwdResetResponse.status <=299) {
      return {
        status: 200,
        data: pwdResetResponse.data
      };
    }
    throw pwdResetResponse;
  } catch (error) {
    return {
      status: error?.status || error,
      data: {},
      error: {
        code: error?.data?.code || 418,
        message: error?.data?.details?.constraintViolations[0]?.message || `Error: ${error}`
      }
    };
  }
};

export { fetchEmailValidationStatus, IValidateResponse,  fetchPasswordPolicy, IPwdPolicyResponse, updatePassword, sendInviteLink };