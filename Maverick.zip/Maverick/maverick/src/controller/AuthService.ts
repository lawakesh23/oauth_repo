import BaseController from "./BaseController";
import { AxiosError, AxiosResponse } from 'axios';

interface IAuthReqBody {
  grant_type: string;
  username: string;
  password: string;
}

interface IAuthRespBody {
  access_token: string;
  expires_in: number;
  scope: Scope;
  refresh_token: string;
}

interface IPwdLoginResponse {
  status: number,
  data: IAuthRespBody,
  error?: {
    code?: number,
    message: string
  }
}

interface Scope {
  user: number;
  partitionName: string;
  partition: Partition;
  capabilities: any[];
}

interface Partition {
  id: number;
  name: string;
}

const loginUser = async (emailToken: string, email: string, password: string) : Promise<IPwdLoginResponse> => {
  try {
    const path = 'seamapi/oauth2/token';
    const reqBody : IAuthReqBody = {
      grant_type: "password",
      username: email,
      password: password
    };
    const pwdResetResponse = await (new BaseController({accessToken: emailToken}).post<IAuthReqBody, IAuthRespBody>(path, reqBody));
    if (pwdResetResponse.status >=200 && pwdResetResponse.status <=299) {
      return {
        status: 200,
        data: pwdResetResponse.data
      };
    }
    throw pwdResetResponse;
  } catch (error) {
    return {
      status: error.status,
      data: null,
      error: {
        code: error?.message?.code || 418,
        message: error?.message?.message || `Error: ${error.statusText}`
      }
    };
  }
};

export { loginUser, IPwdLoginResponse };