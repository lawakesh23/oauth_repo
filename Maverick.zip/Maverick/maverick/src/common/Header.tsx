/** @jsx jsx */
import { jsx, css } from '@emotion/react';
import BjnLogo from "../../static/images/bjn_verizon_logo.svg";

const centerFlex = css({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: '4.3rem'
});

const Header = () : JSX.Element => {
  return (
    <div css={centerFlex}>
      <BjnLogo width="160px" height="62px"/>
    </div>
  );
};

export default Header;