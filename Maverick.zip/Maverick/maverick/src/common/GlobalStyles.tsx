import { Global, css } from "@emotion/react";
import React, { useEffect } from "react";

import ProximaNovaRegularWoff from "../../static/fonts/proximanova-regular.woff2";

import ProximaNovaBoldWoff from "../../static/fonts/proximanova-bold.woff2";

import ProximaNovaSemiBoldWoff from "../../static/fonts/proximanova-semibold.woff2";

import ProximaNovaLightWoff from "../../static/fonts/proximanova-light.woff2";

import ProximaNovaThinWoff from "../../static/fonts/proximanova-thin.woff2";

const GlobalStyles = (): JSX.Element => {
  useEffect(() => {
    const script = document.createElement("script");
    const noscript = document.createElement("noscript");
    const iframe = document.createElement("iframe");

    script.innerHTML = "(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-CXG8');";
    script.async = true;

    iframe.src = "https://www.googletagmanager.com/ns.html?id=GTM-CXG8";
    iframe.style.display = "none";
    iframe.style.visibility = "hidden";
    iframe.height = "0";
    iframe.width = "0";

    document.head.appendChild(script);
    noscript.appendChild(iframe);
    document.body.appendChild(noscript);

    return () => {
      document.body.removeChild(script);
      document.body.removeChild(noscript);
    };
  }, []);

  return (
    <Global
      styles={css`
        @font-face {
          font-family: "ProximaNovaRegular";
          src: url("${ProximaNovaRegularWoff}") format("woff2");
          font-weight: normal;
          font-style: normal;
          font-display: swap;
        }

        @font-face {
          font-family: "ProximaNovaBold";
          src: url("${ProximaNovaBoldWoff}") format("woff2");
          font-weight: normal;
          font-style: normal;
          font-display: swap;
        }

        @font-face {
          font-family: "ProximaNovaSemiBold";
          src: url("${ProximaNovaSemiBoldWoff}") format("woff2");
          font-weight: normal;
          font-style: normal;
          font-display: swap;
        }

        @font-face {
          font-family: "ProximaNovaLight";
          src: url("${ProximaNovaLightWoff}") format("woff2");
          font-weight: normal;
          font-style: normal;
          font-display: swap;
        }

        @font-face {
          font-family: "ProximaNovaThin";
          src: url("${ProximaNovaThinWoff}") format("woff2");
          font-weight: normal;
          font-style: normal;
          font-display: swap;
        }

        html,
        body {
          height: 100%;
          font-family: "ProximaNovaRegular";
          font-size: 14px;
        }
        #root {
          display: flex;
          flex: 1;
          height: 100%;
        }
      `}
    />
  );
};

export default GlobalStyles;
