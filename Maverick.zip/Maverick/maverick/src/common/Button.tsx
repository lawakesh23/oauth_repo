/** @jsx jsx */
import { jsx, css } from '@emotion/react';
import React from 'react';

interface StyledBtnProps {
  secondary?: boolean,
  disabled?: boolean
}

interface Props extends StyledBtnProps{
  onClick: () => void,
  children?: React.ReactNode
}

const styledButton = css({
  display: 'flex',
  alignItems: 'center',
  alignSelf: 'center',
  justifyContent: 'center',
  cursor: 'pointer',
  transition: "0.2s all",
  border: "none",
  boxShadow: "3px 2px 6px 1px rgb(0 0 0 / 12%)",
  color: "#fff",
  "&: active": {
    transform: "scale(0.98)",
    boxShadow: "3px 2px 4px 1px rgba(0, 0, 0, 0.20)"
  }
});

const Button: React.FC<Props> = (props) => {
  const {onClick, disabled, children} = props; 
  return (
    <button css={[styledButton, { backgroundColor: disabled ? "#b9c2cd" : "#0d62c5"}]}
      onClick={onClick}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;
