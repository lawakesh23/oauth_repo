/** @jsx jsx */
import { jsx, css } from "@emotion/react";
import React, { Children } from "react";
import { usePopper } from "react-popper";

const Popper = props => {
  const [popperReference, setPopperReference] = React.useState(null);
  const [popperElement, setPopperElement] = React.useState(null);
  const [arrowElement, setArrowElement] = React.useState(null);

  const { styles: popperStyles, attributes: popperAttributes } = usePopper(
    popperReference,
    popperElement,
    {
      placement: props.placement,
      modifiers: [
        { name: "arrow", options: { element: arrowElement } },
        {
          name: "offset",
          options: {
            offset: [0, 10]
          }
        }
      ]
    }
  );

  const placement =
    popperAttributes &&
    popperAttributes.popper &&
    popperAttributes.popper["data-popper-placement"];

  return (
    <div ref={setPopperReference}>
      <div
        ref={setPopperElement}
        style={popperStyles.popper}
        css={styleContent}
        {...popperAttributes.popper}
      >
        {props.children}
        <div
          ref={setArrowElement}
          style={popperStyles.arrow}
          css={[
            styleArrow,
            placement && placement.startsWith("top") && styleArrowBottom,
            placement && placement.startsWith("bottom") && styleArrowTop,
            placement && placement.startsWith("left") && styleArrowRight,
            placement && placement.startsWith("right") && styleArrowLeft
          ]}
        />
      </div>
    </div>
  );
};

const styleContent = css`
  position: absolute;
  background-color: #ffffff;
`;

const styleArrow = css`
  position: absolute;
  width: 16px;
  height: 16px;
  &:after {
    position: absolute;
    width: 0;
    height: 0;
    content: "";
    pointer-events: none;
    border: 8px solid transparent;
  }
`;

const styleArrowBottom = css`
  bottom: -8px;

  &:after {
    right: 0;
    bottom: 0;
    left: 0;
    border-top-color: #ffffff;
    border-bottom: none;
  }
`;

const styleArrowTop = css`
  top: -8px;

  &:after {
    top: 0;
    left: 0;
    border-bottom-color: #ffffff;
    border-top: none;
  }
`;

const styleArrowLeft = css`
  left: -8px;

  &:after {
    left: 0;
    top: 0;
    border-right-color: #bbb;
    border-left: none;
  }
`;

const styleArrowRight = css`
  right: -8px;

  &:after {
    right: 0;
    top: 20px;
    border-left-color: #fff;
    border-right: none;
  }
`;

export default Popper;