import React from 'react';

import LoaderSpinner from "../../static/images/Spinner_Blue_50px.gif";


const Loader = () : JSX.Element => {
  return (
    <img data-testid="loader" height="49px" width="49px" src={LoaderSpinner} alt="Loading.." />
  );
};

export default Loader;
