/** @jsx jsx */
import { jsx, css } from '@emotion/react';
import React, {FC, InputHTMLAttributes} from 'react';

interface IconTypeProps {
  width: number;
  height: number;
  color: string;
}

type IconType = (props: IconTypeProps) => JSX.Element;

interface Props extends InputHTMLAttributes<HTMLInputElement>{
  name: string;
  icon?: IconType,
  iconClick?: () => void,
  ref?: any,
  hasError?: boolean,
  errorMessage?: string
}

const container = css`
  display: flex;
  justify-content: center;
  align-items: center;
  border: 1px solid #9B9B9B;
  border-radius: 4px;
  &:hover {
    border: 1px solid #FF9702;
  }
  &:focus-within {
    outline: none !important;
    border: 1px solid #0d62c5;
  }
`;

const styledInput = css`
  border: 0;
  border-radius: 4px;
  font-family: ProximaNovaRegular;
  padding: 4px;
  outline: none;
  flex-grow: 1;
`;

const errorInput = css`
border: solid 1px #e01e5a;
`;

const Input: FC<Props> = ({name, icon, iconClick, ref, hasError, ...rest}) => {
  return (
  <div css={[container, hasError ? errorInput : null ]} ref={ref}>
    <input name={name} css={styledInput} {...rest}/>
    {icon && <div css={{marginRight: "1rem"}} onClick={iconClick}>{React.createElement(icon)}</div>}
  </div>
  );
};

export default Input;
