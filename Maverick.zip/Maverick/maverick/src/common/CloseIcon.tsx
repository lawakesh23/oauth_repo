import styled from '@emotion/styled';
import React from 'react';

interface Props extends SvgProps {
  onClick: () => void,
}

interface SvgProps {
  iconWidth?: string,
  iconHeight?: string
}

const Svg = styled.svg<SvgProps>`
  width: ${props => props.iconWidth};
  height: ${props => props.iconHeight};
  cursor: pointer;
`;

const CloseIcon = (props: Props) => {
  return (
    <Svg viewBox="0 0 24 24" onClick={props.onClick} iconWidth={props.iconWidth ? props.iconWidth : "24px"} iconHeight={props.iconHeight ? props.iconHeight : "24px"}>
      <g fill="none" fill-rule="evenodd"><path d="M-3-3h30v30H-3z"/><path fill="#000" opacity=".2" d="M19.956 3L12 10.957 4.043 3 3 4.043 10.957 12 3 19.957 4.043 21 12 13.044 19.956 21 21 19.957 13.043 12 21 4.043z"/></g>
    </Svg>
  );
};

export default CloseIcon;
