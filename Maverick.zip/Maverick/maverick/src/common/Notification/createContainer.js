const createContainer = () => {
  const portalId = "react-notifier";
  let element = document.getElementById(portalId);

  if (element) {
    return element;
  }

  element = document.createElement("div");
  element.setAttribute("id", portalId);
  let css = {
    position: "fixed",
    top: "20px",
    left: "40%"
  };
  Object.assign(element.style, css);
  document.body.appendChild(element);
  return element;
};

export default createContainer;
