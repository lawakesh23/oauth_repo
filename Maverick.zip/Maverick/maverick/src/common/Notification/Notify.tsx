/** @jsx jsx */
import { jsx, css, keyframes } from '@emotion/react';
import styled from '@emotion/styled';
import React, { ReactNode } from 'react';
import { createPortal } from 'react-dom';
import CloseIcon from '../CloseIcon';
import createContainer from './createContainer';

export type Color = "info" | "success" | "warning" | "error";

interface Props {
  color: Color, 
  children: ReactNode,
  onDelete: () => void,
  autoClose?: boolean
}

interface NotifyProps {
  color: string,
  isClosing: boolean
}

const getColor = (color: string) => {
  switch (color) {
    case "error":
      return "#df0e0e";
    case "info":
      return "#0fa1db";
    case "success":
      return "#49a85a";
    case "warning":
      return "#dbbd0f";
  }
};

const slideIn = keyframes`
  from {
    transform: translateY(-100%);
    opacity: 0;
  }

  to {
    transform: translateY(0%);
    opacity: 1;
  }
`;

const slideOut = keyframes`
  from {
    transform: translateY(0%);
    opacity: 1;
  }
  to {
    transform: translateY(-100%);
    opacity: 0;
  }
`;

const NotifyWrapper = styled.div<NotifyProps>`
  display: flex;
  flex-direction: row;
  align-items: center;
  max-width: 430px;
  max-height: 200px;
  min-width: 192px;
  overflow: hidden;
  padding: 12px;
  z-index: 99;
  position: relative;
  background-color: ${props => getColor(props.color)};
  margin-bottom: 8px;
  font-family: ProximaNovaRegular;
  color: #ffffff;
  border-radius: 4px;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.15);
  animation: ${props => !props.isClosing ? slideIn: slideOut} 0.3s ${props => !props.isClosing ? 'ease-in-out': 'ease-out'};
  transition: transform 0.3s ease-out;
`;

const Message = styled.div`
  display: flex;
  flex: 1;
  justify-content: space-around;
`;

const CloseButton = styled.div`
  display: flex;
  margin-left: 12px;
`;

const container = createContainer();
const timeToDelete = 300;
const timeToClose = 1000 * 5;

export const Notify = ({color = "info", children, onDelete, autoClose = true}: Props) => {

  const [isClosing, setIsClosing] = React.useState(false);

  React.useEffect( () => {
    if(isClosing) {
      const timeoutId = setTimeout(onDelete, timeToDelete);
      return () => {
        clearTimeout(timeoutId);
      };
    }
  }, [isClosing, onDelete]);


  React.useEffect(() => {
    if (autoClose) {
      const timeoutId = setTimeout(() => setIsClosing(true), timeToClose);

      return () => {
        clearTimeout(timeoutId);
      };
    }
  }, [autoClose]);

  return createPortal(
    <NotifyWrapper color={color} isClosing={isClosing}>
      <Message>
        {children}
      </Message>
      <CloseButton>
        <CloseIcon onClick={() => setIsClosing(true)} iconHeight="18px" iconWidth="18px"/>
      </CloseButton>
    </NotifyWrapper>, container
  );
};