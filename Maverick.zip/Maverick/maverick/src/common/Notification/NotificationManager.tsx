import React from 'react';
import { Notify } from './Notify';

interface Props {
  setNotify: (message, autoClose, children) => void
}

const NotificationManager = ({setNotify}) => {
  const [notifications, setNotifications] = React.useState([]);

  const createNotification = ({ color, autoClose, children }) => {
    setNotifications((prevNotifications) => {
      return [
        // ...prevNotifications,
        {
          children,
          color,
          autoClose,
          id: prevNotifications.length,
        },
      ];
    });
  };

  React.useEffect(() => {
    setNotify(({ color, autoClose, children }) =>
      createNotification({ color, autoClose, children })
    );
  }, [setNotify]);

  const deleteNotification = (id) => {
    const filteredNotifications = notifications.filter(
      (_, index) => id !== index,
      []
    );
    setNotifications(filteredNotifications);
  };

  return <>{notifications.map(({ id, ...props }, index) => (
    <Notify
      key={id}
      onDelete={() => deleteNotification(index)}
      {...props}
    />
  ))}</>;
};

export default NotificationManager;
