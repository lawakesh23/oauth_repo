import React from "react";
import ReactDOM from "react-dom";
import createContainer from "./createContainer";
import NotificationManager from "./NotificationManager";
import {Notify, Color} from "./Notify";

const containerElement = createContainer();
let notify;

ReactDOM.render(
  <NotificationManager
    setNotify={(notifyFn) => {
      notify = notifyFn;
    }}
  />,
  containerElement
);

export function info(children: any, autoClose=true) {
  return notify({
    color: "info",
    children,
    autoClose
  });
}

export function success(children: any, autoClose=true) {
  return notify({
    color: "success",
    children,
    autoClose,
  });
}

export function warning(children: any, autoClose=true) {
  return notify({
    color: "warning",
    children,
    autoClose,
  });
}

export function error(children: any, autoClose=true) {
  return notify({
    color: "error",
    children,
    autoClose,
  });
}

export { Notify, Color};