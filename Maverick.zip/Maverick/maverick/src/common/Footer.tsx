/** @jsx jsx */
import { jsx, css } from '@emotion/react';

const fontStyle = css`
  font-size: 10px;
  font-weight: normal;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: center;
  color: #4a4a4a;
`;

const link = css`
  color: #0d62c5;
  text-decoration: none;
`;

const Footer = () : JSX.Element => {
  return <span css={fontStyle}>By continuing, I confirm that I have read and understand the <a href="https://www.bluejeans.com/privacy-policy" css={link}>Privacy Policy</a> and <a href="http://bluejeans.com/site/terms-and-conditions" css={link}>Terms of Service.</a></span>;
};

export default Footer;
