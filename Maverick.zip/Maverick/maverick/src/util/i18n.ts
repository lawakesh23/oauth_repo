import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import XHR from 'i18next-http-backend';
import LanguageDetector from "i18next-browser-languagedetector";
 
import * as TRANSLATIONS_FR from "../../static/translation/fr/translation.json";
import * as TRANSLATIONS_DE from "../../static/translation/de/translation.json";
import * as TRANSLATIONS_ES from "../../static/translation/es/translation.json";
import * as TRANSLATIONS_JA from "../../static/translation/ja/translation.json";
import * as TRANSLATIONS_EN from "../../static/translation/en/translation.json";
import * as TRANSLATIONS_PT from "../../static/translation/pt/translation.json";

const resources = {
  en: {
    translation: TRANSLATIONS_EN
  },
  fr: {
    translation: TRANSLATIONS_FR
  },
  es: {
    translation: TRANSLATIONS_ES
  },
  de: {
    translation: TRANSLATIONS_DE
  },
  ja: {
    translation: TRANSLATIONS_JA
  },
  pt: {
    translation: TRANSLATIONS_PT
  }
};

const options = {
  order: ['querystring', 'navigator'],
  lookupQuerystring: 'll'
};

i18n
 .use(XHR)
 .use(LanguageDetector)
 .use(initReactI18next)
 .init({
  detection: options,
  resources,
  returnEmptyString: false,
  ns: ['translation'],
  defaultNS: 'translation',
  fallbackLng: 'en',
  supportedLngs: ['de', 'en', 'es', 'fr', 'ja', 'pt'],
 });
 
 export default i18n;