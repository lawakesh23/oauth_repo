import * as Mixpanel from 'mixpanel-browser';
import BaseController from '../controller/BaseController';

class Analytics {
    private events: any;
    private defaultData: any;
    private mixpanelLocalStorageEventSeperator = "%%$$%%"; //between two mixpanel events
    private mixpanelLocalStorageDataSeperator = "**##**"; // between eventname and data
    private isFlushed = false; //used to indicate if mixpanel data is flushed from localstorage
    private isMixpanelDisabled = false;

    
    
    constructor() {
        this.events = {
            Vz_userLandingCreatePasswordPage: 'Vz_userLandingCreatePasswordPage',
            Vz_userAttemptedCreatePassword: 'Vz_userAttemptedCreatePassword',
            Vz_userRequestNewLink: 'Vz_userRequestNewLink',
            Vz_userCreatedNewPassword: 'Vz_userCreatedNewPassword'
        };
        try {
            this.isMixpanelDisabled = window.BJN.userFeatures.find(function(feature) {
                return feature.name === "disable_mixpanel";
            })[0]?.available;
        } catch (error) {
            console.log(error);
        }
        if (window?.BJN?.disableMixpanel)
            window.BJN.disableMixpanel = this.isMixpanelDisabled;

        this.defaultData = {};
        if(!window.BJN?.Analytics)
            this.initializeMixpanel();
    }

    async getAnalyticsToken () {
        try {
            const analyticsPath = '/analytics/token/';
            const response = await (new BaseController().get(analyticsPath));
            return response;
        } catch (error) {
            console.log(error);
            console.log("mixpanel init failed");
        }
    }

    initializeMixpanel () {
        this.getAnalyticsToken().then((response: any) => {
            try {
                window.BJN.Analytics = Mixpanel;
                window.BJN.Analytics.init(response.token, {
                    property_blacklist: ['$current_url', '$referrer', '$initial_referrer', 'mp_page', 'mp_referrer']
                });
            } catch (err) { console.log("mixpanel init failed"); }
        }, (error) => console.error("mixpanel init failed"));
    }

    trackEvent(eventName, eventData) {
        eventData = this.mergeDeep({}, eventData, this.defaultData);
        if(window.BJN?.Analytics) {
            !this.isFlushed ? this.flushLocalStoragetoMixpanel() : "";
            if (!window.BJN.disableMixpanel) {
                window.BJN.Analytics.track(this.events[eventName], eventData);
            }
        } else {
            this.appendToLocalStorage(this.events[eventName], eventData);
        }
    }

    isObject(item: any) {
        return (item && typeof item === 'object' && !Array.isArray(item));
    }

    appendToLocalStorage(eventName, eventData) {
        if(window.localStorage.getItem("bjn_mp")) {
            const customData = window.localStorage.getItem("bjn_mp") + this.mixpanelLocalStorageEventSeperator + eventName + this.mixpanelLocalStorageDataSeperator + JSON.stringify(eventData);
            window.localStorage.setItem("bjn_mp", customData);
        } else {
            const customData = eventName + this.mixpanelLocalStorageDataSeperator + JSON.stringify(eventData);
            window.localStorage.setItem("bjn_mp", customData);
        }
    }

    flushLocalStoragetoMixpanel() {
        this.isFlushed = true;
        if(window.localStorage.getItem("bjn_mp")) {
            const mixpanelData = window.localStorage.getItem("bjn_mp");
            window.localStorage.removeItem("bjn_mp");
            const mixpanelDataArr = mixpanelData.split(this.mixpanelLocalStorageEventSeperator);
            for(const data of mixpanelDataArr) {
                const event = data.split(this.mixpanelLocalStorageDataSeperator);
                if(event[0] && event[1]) {
                    window.BJN.Analytics.track(event[0], JSON.parse(event[1]));
                }
            }
        }
    }
    
    mergeDeep(target: any, ...sources) {
        if (!sources.length) return target;
        const source = sources.shift();
      
        if (this.isObject(target) && this.isObject(source)) {
          for (const key in source) {
            if (this.isObject(source[key])) {
              if (!target[key]) Object.assign(target, { [key]: {} });
              this.mergeDeep(target[key], source[key]);
            } else {
              Object.assign(target, { [key]: source[key] });
            }
          }
        }  
        return this.mergeDeep(target, ...sources);
    }
}
export default new Analytics();