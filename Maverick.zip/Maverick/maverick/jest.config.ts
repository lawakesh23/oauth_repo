import { Config } from '@jest/types';
const config: Config.InitialOptions = {
    verbose: true,
    bail: 1,
    collectCoverage: true,
    testEnvironment: 'jsdom',
    roots: ['<rootDir>/src'],
    moduleNameMapper: {
        "\\.(jpg|ico|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$": "<rootDir>/src/__test__/__mocks__/dummyImage.ts",
        "\\.(css|less|gif)$": "<rootDir>/src"
    },

    testRegex: '(/__test__/.*|(\\.|/)(test))\\.tsx?$',
    // Module file extensions for importing
    moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json' ]
};
export default config;
