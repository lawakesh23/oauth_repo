import path from 'path';
import webpack from 'webpack';
import {exec} from 'child_process';
import {merge} from require('webpack-merge');
import common from './webpack.common.js';
import MiniCssExtractPlugin from "mini-css-extract-plugin";
import HtmlWebpackPlugin from 'html-webpack-plugin';

module.exports = merge(common.config, {
    mode: 'development',
    devtool: 'inline-source-map',
    output: {
      path: path.resolve(__dirname, './dist'),
      publicPath: '/'
    },
    devServer: {
      historyApiFallback: true,
      proxy: {
        '/v1/*': {
          target: 'https://aayush.bluejeansnet.com',
          secure: false,
        },
        
      }
     },
    //devtool: "cheap-module-eval-source-map", //use for cleaner build
    module: {   //for unbundled files
        rules: [
            {
                test: /\.(css|less)$/,
                use: [
                  {
                    loader: MiniCssExtractPlugin.loader
                  },
                  {
                      loader: 'css-loader',
                      options: { 
                        url: false,
                        sourceMap: true,
                      }
                  },
                  {
                      loader: 'less-loader',
                      options: {
                        lessOptions: {
                          relativeUrls: false,
                        },
                        sourceMap: true,
                      }
                  }
              ]
            }
        ]
    },
    plugins: [  //for bundled files
        new webpack.DefinePlugin({
            'STATIC_ASSETS_MAVERICK_PATH': '\'/maverick/target/' + `${common.versionName}` + '/\''
        }),

        new MiniCssExtractPlugin({
          filename: './maverick.css'
        }),
        new HtmlWebpackPlugin({
          template: './example/index.html',
          filename: 'index.html',
          path: "./dist/",
        }),
        {
            apply: (compiler) => {
              compiler.hooks.afterEmit.tap('AfterEmitPlugin', (compilation) => {
                exec('cd target/ && tar czf ' +`${common.getVersionTag()}`+'.tar.gz * && cd ..', (err, stdout, stderr) => {
                  if (stdout) process.stdout.write(stdout);
                  if (stderr) process.stderr.write(stderr);
                });
              });
            }
        }
    ]
});