
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>JS Bin</title>
</head>
<body>
  <div id='test'> This is div element </div>
</body>

<script>
function x(){
     var a=7;
     function y(){
        console.log(a);
     }
return y;
}

var z= x();
console.log(z);
z();


document.querySelector("#test").addEventListener('click', ()=>{
    console.log('test click');
   var newElemnt= document.createElement("div");
   document.body.appendChild(newElemnt)
})
</script>
</html>

